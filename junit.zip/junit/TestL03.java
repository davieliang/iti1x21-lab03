public class TestL03 {

   public static void main(String[] args) {
    TestUtils.runClass(TestL3Utils.class);
    TestUtils.runClass(TestL3Rational.class);
  }

}
